package opusm.assignment.client;

import opusm.assignment.client.dto.ClientDto;
import opusm.assignment.client.entity.Client;
import opusm.assignment.client.repository.ClientRepository;
import opusm.assignment.client.service.ClientService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Transactional
@SpringBootTest
public class ClientServiceTest {

    @Autowired
    ClientRepository clientRepository;
    @Autowired
    ClientService clientService;

    @Test
    void addClient() {
        Long clientId = clientService.addClient("client1");
        Client client = clientRepository.findById(clientId);

        Assertions.assertEquals(client.getName(), "client1");
    }

    @Test
    void getClient() {
        Long clientId = clientService.addClient("client2");
        Client client1 = clientService.getClient(clientId);

        Assertions.assertEquals(client1.getName(), "client2");
    }

    @Test
    void getAllClients() {
        clientService.addClient("client1");
        clientService.addClient("client2");
        clientService.addClient("client3");

        List<ClientDto> allClients = clientService.getAllClients();
        for (int i = 0; i < allClients.size(); i++)
            Assertions.assertEquals(allClients.get(i).getName(), "client" + (i+1));
    }
}
