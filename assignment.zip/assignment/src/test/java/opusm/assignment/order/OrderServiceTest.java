package opusm.assignment.order;

import opusm.assignment.cart.entity.CartItem;
import opusm.assignment.cart.repository.CartItemRepository;
import opusm.assignment.client.entity.Client;
import opusm.assignment.client.repository.ClientRepository;
import opusm.assignment.item.dto.ItemDto;
import opusm.assignment.item.entity.Item;
import opusm.assignment.item.repository.ItemRepository;
import opusm.assignment.item.type.Franchise;
import opusm.assignment.order.dto.OrderDto;
import opusm.assignment.order.repository.OrderRepository;
import opusm.assignment.order.service.OrderService;
import opusm.assignment.order.type.PaymentType;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Transactional
@SpringBootTest
public class OrderServiceTest {

    @Autowired
    ClientRepository clientRepository;
    @Autowired
    ItemRepository itemRepository;
    @Autowired
    CartItemRepository cartItemRepository;
    @Autowired
    OrderRepository orderRepository;
    @Autowired
    OrderService orderService;

    @Test
    void order() {
        Client client = Client.joinClient("client1");
        clientRepository.save(client);

        List<CartItem> cartItemList = new ArrayList<>();

        ItemDto itemDto = new ItemDto();
        itemDto.setName("item1");
        itemDto.setStock(3);
        itemDto.setPrice(1000);
        itemDto.setPointEarnPercent(10);
        itemDto.setFranchise(Franchise.GS25);

        Item item = Item.addItem(itemDto);
        itemRepository.save(item);

        CartItem cartItem = CartItem.addItem(item, 1);
        cartItemRepository.save(cartItem);

        cartItemList.add(cartItem);

        itemDto = new ItemDto();
        itemDto.setName("item2");
        itemDto.setStock(4);
        itemDto.setPrice(2000);
        itemDto.setPointEarnPercent(15);
        itemDto.setFranchise(Franchise.CGV);

        item = Item.addItem(itemDto);
        itemRepository.save(item);

        cartItem = CartItem.addItem(item, 2);
        cartItemRepository.save(cartItem);

        cartItemList.add(cartItem);

        OrderDto orderDto = new OrderDto();
        orderDto.setClientId(client.getId());
        orderDto.setPaymentType(PaymentType.POINT);

        List<Long> cartItemIdList = cartItemList.stream().map(cartItem1 ->
                cartItem1.getId()).toList();
        orderDto.setCartItemIdList(cartItemIdList);
        orderService.orderCartItem(orderDto);

        Assertions.assertThat(client.getPoint()).isEqualTo(5000);






    }


}
