package opusm.assignment.cart;

import opusm.assignment.cart.dto.CartItemDto;
import opusm.assignment.cart.entity.Cart;
import opusm.assignment.cart.entity.CartItem;
import opusm.assignment.cart.repository.CartItemRepository;
import opusm.assignment.cart.repository.CartRepositoryImpl;
import opusm.assignment.cart.service.CartService;
import opusm.assignment.client.entity.Client;
import opusm.assignment.client.repository.ClientRepository;
import opusm.assignment.item.dto.ItemDto;
import opusm.assignment.item.repository.ItemRepository;
import opusm.assignment.item.type.Franchise;
import opusm.assignment.item.entity.Item;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import java.util.List;
import java.util.Optional;

@Transactional
@SpringBootTest
public class CartServiceTest {

    @Autowired
    EntityManager em;
    @Autowired
    CartRepositoryImpl cartRepositoryImpl;
    @Autowired
    CartItemRepository cartItemRepository;
    @Autowired
    ClientRepository clientRepository;
    @Autowired
    ItemRepository itemRepository;
    @Autowired
    CartService cartService;

    @BeforeEach
    void before() {

    }

    @Test
    void putInCart() {
        Client client = Client.joinClient("guest1");
        clientRepository.save(client);

        ItemDto dto = new ItemDto();
        dto.setName("item1");
        dto.setFranchise(Franchise.GS25);
        dto.setPrice(1000);
        dto.setStock(10);
        dto.setPointEarnPercent(20);

        Item item = Item.addItem(dto);
        itemRepository.save(item);



        CartItemDto cartItemDto = new CartItemDto();
        cartItemDto.setQuantity(5);
        cartItemDto.setClientId(client.getId());
        cartItemDto.setItemId(item.getId());

        Long cartItemId = cartService.putInCart(cartItemDto);

        Cart cart = cartRepositoryImpl.findByUserId(client.getId());
        CartItem cartItem = cartItemRepository.findById(cartItemId).orElseThrow();

        Assertions.assertThat(cartItemDto.getItemId()).isEqualTo(cartItem.getItem().getId());
        //Assertions.assertThat()

    }


}
