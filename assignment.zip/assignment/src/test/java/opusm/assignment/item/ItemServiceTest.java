package opusm.assignment.item;

import opusm.assignment.item.dto.ItemDto;
import opusm.assignment.item.entity.Item;
import opusm.assignment.item.repository.ItemRepository;
import opusm.assignment.item.service.ItemService;
import opusm.assignment.item.type.Franchise;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Transactional
@SpringBootTest
public class ItemServiceTest {

    @Autowired
    ItemRepository itemRepository;
    @Autowired
    ItemService itemService;

    @Test
    void addItem() {
        ItemDto dto = new ItemDto();
        dto.setName("item1");
        dto.setFranchise(Franchise.GS25);
        dto.setPrice(1000);
        dto.setStock(10);
        dto.setPointEarnPercent(20);

        long itemId = itemService.addItem(dto);

        Item item1 = itemRepository.findById(itemId);

        Assertions.assertThat(item1.getName()).isEqualTo(dto.getName());
    }
}
