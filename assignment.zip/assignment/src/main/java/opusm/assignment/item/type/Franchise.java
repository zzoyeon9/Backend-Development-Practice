package opusm.assignment.item.type;

public enum Franchise {
    GS25, HomePlus, CGV
}
