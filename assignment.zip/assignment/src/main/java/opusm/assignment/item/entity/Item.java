package opusm.assignment.item.entity;

import com.sun.istack.NotNull;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import opusm.assignment.exception.NotEnoughStockException;
import opusm.assignment.item.dto.ItemDto;
import opusm.assignment.item.type.Franchise;

import javax.persistence.*;

@Entity
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Item {

    @Id @GeneratedValue
    @Column(name = "item_Id")
    private Long id;

    @Column @NotNull
    private String name;
    @Column
    private int price;
    @Column
    private int stock;
    @Column
    private int pointEarnPercent;
    @Column
    private Franchise franchise;

    public static Item addItem(ItemDto dto) {
        Item item = new Item();
        item.name = dto.getName();
        item.franchise = dto.getFranchise();
        item.pointEarnPercent = dto.getPointEarnPercent();
        item.price = dto.getPrice();
        item.stock = dto.getStock();

        return item;
    }

    public void addStock(int quantity) {
        this.stock += quantity;
    }

    public void removeStock(int quantity) {
        int restStock = this.stock - quantity;
        if(restStock<0)
            throw new NotEnoughStockException("Need more stock.");
        this.stock = restStock;
    }
}
