package opusm.assignment.item.service;

import opusm.assignment.item.dto.ItemDto;
import opusm.assignment.item.entity.Item;

import java.util.List;

public interface ItemService {
    long addItem(ItemDto dto);
    List<ItemDto> getItemList();
}
