package opusm.assignment.item.service;

import lombok.RequiredArgsConstructor;

import opusm.assignment.item.dto.ItemDto;
import opusm.assignment.item.entity.Item;
import opusm.assignment.item.repository.ItemRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
public class ItemServiceImpl implements ItemService {

    private final ItemRepository itemRepository;

    @Override
    public long addItem(ItemDto dto) {
        Item item = Item.addItem(dto);
        itemRepository.save(item);
        return item.getId();
    }

    @Override
    public List<ItemDto> getItemList() {

        return itemRepository.findAll().stream()
                .map(item -> {
                    ItemDto dto = new ItemDto();
                    dto.setName(item.getName());

                    return dto;
                })
                .toList();
    }
}
