package opusm.assignment.item.controller;

import lombok.RequiredArgsConstructor;
import opusm.assignment.item.dto.ItemDto;
import opusm.assignment.item.service.ItemService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class ItemController {

    private final ItemService itemService;

    @PostMapping("/api/item/add")
    public void addItem(@RequestBody ItemDto dto) {
        itemService.addItem(dto);
    }

    @GetMapping("/api/item/list")
    public List<ItemDto> getList() {
        return itemService.getItemList();
    }
}
