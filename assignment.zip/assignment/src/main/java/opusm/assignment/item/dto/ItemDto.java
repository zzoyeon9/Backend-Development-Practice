package opusm.assignment.item.dto;

import com.sun.istack.NotNull;
import lombok.Data;
import lombok.Getter;
import opusm.assignment.item.type.Franchise;

import javax.persistence.Column;

@Data
public class ItemDto {

    private String name;
    private int price;
    private int stock;
    private int pointEarnPercent;
    private Franchise franchise;
}
