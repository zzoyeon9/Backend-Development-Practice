package opusm.assignment.client.controller;

import lombok.RequiredArgsConstructor;
import opusm.assignment.client.dto.ClientDto;
import opusm.assignment.client.entity.Client;
import opusm.assignment.client.service.ClientService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class ClientController {

    private final ClientService clientService;

    @PostMapping("/api/client/join")
    public void registerClient(@RequestBody ClientDto dto) {
        clientService.addClient(dto.getName());
    }

    @GetMapping("/api/client/list")
    public List<ClientDto> getClientList() {
        return clientService.getAllClients();
    }

}
