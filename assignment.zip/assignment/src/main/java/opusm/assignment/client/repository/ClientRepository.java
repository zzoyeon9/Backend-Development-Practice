package opusm.assignment.client.repository;

import lombok.RequiredArgsConstructor;
import opusm.assignment.client.entity.Client;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import java.util.List;

@Repository
@RequiredArgsConstructor
public class ClientRepository {

    private final EntityManager em;

    public void save(Client client) {
        em.persist(client);
    }

    public Client findById(Long id) {
        return em.find(Client.class, id);
    }

    public Client findByName(String name) {
        return em.createQuery("select c from Client c where c.name = :name", Client.class)
                .setParameter("name", name)
                .getSingleResult();
    }

    public List<Client> findAll() {
        List<Client> clientList = em.createQuery("select c from Client c", Client.class)
                .getResultList();
        return clientList;
    }

}
