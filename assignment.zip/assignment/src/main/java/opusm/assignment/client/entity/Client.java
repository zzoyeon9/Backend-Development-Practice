package opusm.assignment.client.entity;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import opusm.assignment.cart.entity.Cart;
import opusm.assignment.order.entity.Order;
import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

import static javax.persistence.FetchType.LAZY;

@Entity
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Client {

    @Column
    @Id @GeneratedValue
    private Long id;

    @Column
    private String name;

    @Column
    private int cash;

    @Column
    private int point=10000;

    @OneToOne(mappedBy = "client", fetch = LAZY, cascade = CascadeType.ALL)
    private Cart cart;

    /**
     * 체
     */
    @OneToMany(mappedBy = "client")
    private List<Order> orderList = new ArrayList<>();


//==연관 관계 메서드==//

    /**
     * Order 삽입
     * @param order
     */
    public void addOrder(Order order) {
        orderList.add(order);
    }
//================//

    /**
     * Client 생성 메서드
     *
     * @param name
     * @return Client
     */
    public static Client joinClient(String name) {
        Client client = new Client();
        client.name = name;
        client.cash = 0;
        client.cart = Cart.createCart(client);

        return client;
    }

    /**
     * 캐시 잔액 충전 메서드
     *
     * @param cash
     */
    public void cashRefill(int cash) {
        this.cash += cash;
    }

    public void updateCash(int sumPrice) {
        this.cash = this.getCash() - sumPrice;
    }

    public void updatePoint(int sumPrice) {
        this.point = this.getPoint() - sumPrice;
    }
}
