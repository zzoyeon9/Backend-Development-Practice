package opusm.assignment.client.service;

import lombok.RequiredArgsConstructor;
import opusm.assignment.client.dto.ClientDto;
import opusm.assignment.client.entity.Client;
import opusm.assignment.client.repository.ClientRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional(readOnly = true)
@RequiredArgsConstructor
public class ClientServiceImpl implements ClientService {

    private final ClientRepository clientRepository;

    @Override
    public Client getClient(Long memberId) {
        return clientRepository.findById(memberId);
    }

    @Override
    public Long addClient(String name) {
        Client client = Client.joinClient(name);
        clientRepository.save(client);
        return client.getId();
    }

    @Override
    public List<ClientDto> getAllClients() {
        return clientRepository.findAll().stream()
                .map(client -> {
                    ClientDto dto = new ClientDto();
                    dto.setName(client.getName());

                    return dto;
                })
                .toList();
    }
}
