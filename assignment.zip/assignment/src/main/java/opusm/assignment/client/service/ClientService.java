package opusm.assignment.client.service;

import opusm.assignment.client.dto.ClientDto;
import opusm.assignment.client.entity.Client;

import java.util.List;

public interface ClientService {

    Client getClient(Long memberId);
    Long addClient(String name);
    List<ClientDto> getAllClients();
}
