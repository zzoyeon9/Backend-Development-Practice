package opusm.assignment.client.dto;

import lombok.Data;

@Data
public class ClientDto {

    private String name;
}
