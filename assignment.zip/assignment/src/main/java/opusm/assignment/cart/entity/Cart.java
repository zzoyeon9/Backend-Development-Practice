package opusm.assignment.cart.entity;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import opusm.assignment.client.entity.Client;

import javax.persistence.*;

import java.util.ArrayList;
import java.util.List;

import static javax.persistence.FetchType.LAZY;

@Entity
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Cart {

    @Id @GeneratedValue
    @Column(name = "cart_id")
    private Long id;

    @JoinColumn(name = "client_id")
    @OneToOne(fetch = LAZY)
    private Client client;

    @OneToMany(mappedBy = "cart")
    private List<CartItem> cartItemList = new ArrayList<>();

    /**
     * 생성 메서드
     * @param client
     * @return
     */

    public static Cart createCart(Client client) {
        Cart cart = new Cart();
        cart.client = client;
        return cart;
    }

    /**
     * 연관관계 메서드
     * @param cartItems
     * @return
     */
    public Cart addCartItem(CartItem... cartItems) {
        Cart cart = new Cart();
        for(CartItem cartItem : cartItems)
        cartItemList.add(cartItem);

        return cart;
    }

    /**
     * 간단한 비즈니스 로직(DDD)
     * @param cartItem
     */
    public void removeCartItem(CartItem cartItem) {

        cartItemList.remove(cartItem);
    }

}

