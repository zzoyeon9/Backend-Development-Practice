package opusm.assignment.cart.service;

import opusm.assignment.cart.dto.CartItemDto;

import java.util.List;

public interface CartService {

    Long putInCart(CartItemDto dto);
    void removeFromCart(List<Long> cartItemIdList);
}
