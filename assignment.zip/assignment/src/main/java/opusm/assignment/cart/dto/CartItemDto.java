package opusm.assignment.cart.dto;

import lombok.Data;

@Data
public class CartItemDto {

    private Long clientId;
    private Long itemId;
    private int quantity;
}
