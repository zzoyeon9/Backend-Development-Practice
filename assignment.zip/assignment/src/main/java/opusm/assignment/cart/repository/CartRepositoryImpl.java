package opusm.assignment.cart.repository;

import lombok.RequiredArgsConstructor;
import opusm.assignment.cart.entity.Cart;
import opusm.assignment.client.entity.Client;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;

@Repository
@RequiredArgsConstructor
public class CartRepositoryImpl implements CartRepository{

    private final EntityManager em;

    public void save(Cart cart) {
        em.persist(cart);
    }

    public Cart findOne(Long id) {
        return em.find(Cart.class, id);
    }

    public Cart findByUserId(Long clientId) {
        Client client = em.find(Client.class, clientId);
        return client.getCart();


        /*em.createQuery("select ci from CartItem ci where ci.cart =:cart and ci.item =:item", CartItem.class)
                .setParameter("cart", cart)
                .setParameter("item", item)
                .getResultList();*/
    }
}
