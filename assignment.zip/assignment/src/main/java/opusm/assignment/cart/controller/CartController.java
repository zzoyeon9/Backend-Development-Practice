package opusm.assignment.cart.controller;

import lombok.RequiredArgsConstructor;
import opusm.assignment.cart.dto.CartItemDto;
import opusm.assignment.cart.service.CartService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class CartController {
    private final CartService cartService;

    @PostMapping("/api/cart/add")
    public void addCartItem(@RequestBody CartItemDto dto) {
        cartService.putInCart(dto);
    }

    @DeleteMapping("/api/cart/delete")
    public void deleteCartItem(@RequestParam List<Long> cartItemId) {
        cartService.removeFromCart(cartItemId);
    }

}
