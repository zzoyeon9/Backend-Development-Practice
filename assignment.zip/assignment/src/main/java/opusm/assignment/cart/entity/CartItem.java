package opusm.assignment.cart.entity;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import opusm.assignment.item.entity.Item;
import opusm.assignment.order.entity.Order;

import javax.persistence.*;

import static javax.persistence.FetchType.LAZY;

@Entity
@Getter
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class CartItem {

    @Id
    @GeneratedValue
    @Column(name = "cart_item_id")
    private Long id;

    @JoinColumn(name = "cart_id")
    @ManyToOne(fetch = LAZY, cascade = CascadeType.ALL)
    private Cart cart;

    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "order_id")
    private Order order;

    @JoinColumn(name = "item_id")
    @ManyToOne(fetch = LAZY, cascade = CascadeType.ALL)
    private Item item;

    @Column
    private int quantity;

    public static CartItem addItem(Item item, int quantity) {
        CartItem cartItem = new CartItem();
        cartItem.item = item;
        cartItem.quantity = quantity;
        item.removeStock(quantity);
        return cartItem;
    }

    public void updateQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void cancel() {
        getItem().addStock(quantity);
    }
}
