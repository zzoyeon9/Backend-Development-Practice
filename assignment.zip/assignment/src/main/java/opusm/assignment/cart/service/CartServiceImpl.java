package opusm.assignment.cart.service;

import lombok.RequiredArgsConstructor;
import opusm.assignment.cart.dto.CartItemDto;
import opusm.assignment.cart.repository.CartItemRepository;
import opusm.assignment.cart.repository.CartRepository;
import opusm.assignment.cart.entity.Cart;
import opusm.assignment.cart.entity.CartItem;
import opusm.assignment.client.entity.Client;
import opusm.assignment.client.repository.ClientRepository;
import opusm.assignment.exception.NotExistItemInCartException;
import opusm.assignment.item.entity.Item;
import opusm.assignment.item.repository.ItemRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
public class CartServiceImpl implements CartService {

    private final CartRepository cartRepository;
    private final ItemRepository itemRepository;
    private final ClientRepository clientRepository;
    private final CartItemRepository cartItemRepository;

    @Override
    public Long putInCart(CartItemDto dto) {
        Client client = clientRepository.findById(dto.getClientId());

        Item item = itemRepository.findById(dto.getItemId());

        Cart cart = cartRepository.findByUserId(client.getId());

        CartItem cartItem = cartItemRepository.findByCartIdAndItemId(cart.getId(), item.getId());

        if (cartItem == null) {//최초 주문 시
            cartItem = CartItem.addItem(item,  dto.getQuantity());
            cartItemRepository.save(cartItem);
            cart.addCartItem(cartItem);
        } else//이미 담은 상품일 경우
            cartItem.updateQuantity(cartItem.getQuantity() + dto.getQuantity());
        //수량 ++
        return cartItem.getId();

/*        Client client = clientRepository.findOne(memberId);
        client.addCart(cart);*/
    }

    public void removeFromCart(List<Long> cartItemIdList) throws NotExistItemInCartException {
        cartItemRepository.deleteAllById(cartItemIdList);
    }
}
