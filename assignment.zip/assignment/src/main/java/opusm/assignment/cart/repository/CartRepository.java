package opusm.assignment.cart.repository;

import opusm.assignment.cart.entity.Cart;

public interface CartRepository {
    void save(Cart cart);
    Cart findOne(Long id);
    Cart findByUserId(Long clientId);
}
