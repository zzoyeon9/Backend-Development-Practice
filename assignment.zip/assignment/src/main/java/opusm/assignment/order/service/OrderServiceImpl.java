package opusm.assignment.order.service;

import lombok.RequiredArgsConstructor;
import opusm.assignment.cart.entity.Cart;
import opusm.assignment.cart.entity.CartItem;
import opusm.assignment.cart.repository.CartItemRepository;
import opusm.assignment.cart.repository.CartRepositoryImpl;
import opusm.assignment.client.entity.Client;
import opusm.assignment.client.repository.ClientRepository;
import opusm.assignment.exception.NotEnoughPointException;
import opusm.assignment.order.dto.OrderDto;
import opusm.assignment.order.entity.Order;
import opusm.assignment.order.repository.OrderRepository;
import opusm.assignment.order.type.PaymentType;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {

    private final ClientRepository clientRepository;
    private final CartItemRepository cartItemRepository;
    private final OrderRepository orderRepository;


    @Override
    public void orderCartItem(OrderDto dto) {
        Client client = clientRepository.findById(dto.getClientId());
        List<CartItem> cartItemList = cartItemRepository.findAllById(dto.getCartItemIdList());

        Order order = Order.createOrder(cartItemList, client);

        if (dto.getPaymentType() == PaymentType.POINT) {
            for (CartItem cartItem : cartItemList) {
                int sumPrice = cartItem.getItem().getPrice() * cartItem.getQuantity();

                if (client.getPoint() - sumPrice < 0)
                    throw new NotEnoughPointException("Not Enough Point");

                client.updatePoint(client.getPoint() - sumPrice);
            }
        }
        else {
            for (CartItem cartItem : cartItemList) {
                int thisPrice = cartItem.getItem().getPrice() * cartItem.getQuantity();
                int earnPoint = thisPrice * (cartItem.getItem().getPointEarnPercent() / 100);

                client.updateCash(client.getCash() - thisPrice);
                client.updatePoint(client.getPoint() + earnPoint);
            }
        }
        orderRepository.save(order);
    }
}
