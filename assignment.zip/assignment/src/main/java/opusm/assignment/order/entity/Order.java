package opusm.assignment.order.entity;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import opusm.assignment.cart.entity.Cart;
import opusm.assignment.cart.entity.CartItem;
import opusm.assignment.client.entity.Client;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static javax.persistence.FetchType.LAZY;


@Entity
@Getter
@Table(name = "orders") //예약어 방지
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class Order {

    @Id @GeneratedValue
    @Column(name = "order_id")
    private Long id;

    @OneToMany(mappedBy = "order", fetch = LAZY)
    private List<CartItem> cartItemList = new ArrayList<>();

    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "client_id")
    private Client client;

    private LocalDateTime orderDate;
/**
 * 연관관계 메서드
 */
    public static Order createOrder(List<CartItem> cartItemList, Client client) {
        Order order = new Order();
        order.cartItemList = cartItemList;
        order.client = client;
        order.orderDate = LocalDateTime.now();
        return order;
    }

}
