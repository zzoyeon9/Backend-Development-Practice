package opusm.assignment.order.controller;

import lombok.RequiredArgsConstructor;
import opusm.assignment.order.dto.OrderDto;
import opusm.assignment.order.service.OrderService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class OrderController {

    private final OrderService orderService;

    @PostMapping("/api/order/pay")
    public void pay(OrderDto dto) {
        orderService.orderCartItem(dto);
    }

}
