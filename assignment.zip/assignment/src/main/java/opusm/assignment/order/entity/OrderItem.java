package opusm.assignment.order.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import opusm.assignment.client.entity.Client;

import javax.persistence.*;

import static javax.persistence.FetchType.LAZY;

@Entity
@NoArgsConstructor
@Getter
public class OrderItem {

    @Id @GeneratedValue
    private Long id;

    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "order_id")
    private Order order;

    @ManyToOne(fetch = LAZY)
    @JoinColumn(name = "client_id")
    private Client client;

    private int itemPrice;
    private int itemQuantity;

}
