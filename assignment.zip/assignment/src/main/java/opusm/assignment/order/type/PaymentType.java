package opusm.assignment.order.type;

public enum PaymentType {
    CASH, POINT
}
