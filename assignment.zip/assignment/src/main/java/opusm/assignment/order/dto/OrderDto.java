package opusm.assignment.order.dto;

import lombok.Data;
import opusm.assignment.order.type.PaymentType;

import java.util.List;

@Data
public class OrderDto {
    private PaymentType paymentType;
    private long clientId;
    private List<Long> cartItemIdList;
}
