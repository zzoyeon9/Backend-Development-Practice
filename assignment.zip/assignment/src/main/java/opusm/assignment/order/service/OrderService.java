package opusm.assignment.order.service;

import opusm.assignment.order.dto.OrderDto;

public interface OrderService {

    void orderCartItem(OrderDto dto);

}
