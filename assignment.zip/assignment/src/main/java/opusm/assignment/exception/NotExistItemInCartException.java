package opusm.assignment.exception;

public class NotExistItemInCartException extends RuntimeException{
    public NotExistItemInCartException(String message) {
        super(message);
    }
}
