package opusm.assignment.exception;

public class NotEnoughPointException extends RuntimeException{
    public NotEnoughPointException(String message) {

        super(message);
    }
}
